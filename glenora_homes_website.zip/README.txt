GLENORA HOMES WEBSITE

Files:
- index.html: complete responsive one-page website.

How to publish with GitHub Pages:
1. Create a new public repository on GitHub, for example: glenora-homes.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select main and /(root), then Save.
6. Wait for GitHub Pages to publish the site; the live address will appear in Settings > Pages.

Before publishing:
- Confirm that +254 717 034 710 is the correct Glenora Homes WhatsApp number.
- Replace any service descriptions that do not match what you can currently deliver.
- Add your preferred email and social media links if available.
- The sample photos are loaded from Unsplash and require an internet connection.
